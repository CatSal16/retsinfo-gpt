# Retsinformation GPT Action

FastAPI-tjeneste og OpenAPI-specifikation til brug i ChatGPT-handlinger.