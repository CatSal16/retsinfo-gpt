from fastapi import FastAPI, Query
import requests

app = FastAPI()

BASE_URL = "https://retsinformation.dk/api/document"

@app.get("/lovgivning")
def hent_gaeldende_lovgivning(search: str = Query(..., description="Søgeord for lovgivning")):
    params = {
        "SearchText": search,
        "OnlyActive": "true",
        "PageSize": 5
    }
    response = requests.get(BASE_URL, params=params)
    if response.status_code != 200:
        return {"error": "Kunne ikke hente data fra retsinformation.dk"}
    
    data = response.json()
    results = []
    for doc in data.get("Documents", []):
        results.append({
            "titel": doc.get("Title"),
            "id": doc.get("Id"),
            "type": doc.get("DocumentType"),
            "dato": doc.get("PublicationDate"),
            "eli": doc.get("Eli"),
            "link": f"https://retsinformation.dk/eli/{doc.get('Eli')}" if doc.get("Eli") else None
        })

    return {"resultater": results}
